package com.cg.pod.service;

import java.util.ArrayList;
import java.util.Collection;

import com.cg.pod.entity.PetEntity;

public class PetServiceImpl implements PetServiceInterface
{
	ArrayList<PetEntity> arrayList=new ArrayList<PetEntity>();
	public void add1(String str) 
	{
		//System.out.println(str);		
		arrayList.add(str);
	}

	public void delete() {
		// TODO Auto-generated method stub
		
	}

	public void update() {
		// TODO Auto-generated method stub
		
	}

	public void viewAll() {
		// TODO Auto-generated method stub
		
	}


	


}
